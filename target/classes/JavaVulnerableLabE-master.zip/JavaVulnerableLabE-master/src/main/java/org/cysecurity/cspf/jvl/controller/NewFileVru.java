public class NewFileVru{
  public String password = "Vrushali";
}
